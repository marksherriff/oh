//
//  AppDelegate.m
//  OfficeHours
//
//  Created by Dan Miller on 4/2/13.
//  Copyright (c) 2013 Dan Miller. All rights reserved.
//

#import "AppDelegate.h"

@implementation AppDelegate

@synthesize statusBar = _statusBar;

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification
{
    // Insert code here to initialize your application
   
}

- (void) getCount{
    NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:@"http://stardock.cs.virginia.edu/miller/queue_count.php"]];
    NSData *response = [NSURLConnection sendSynchronousRequest:request returningResponse:nil error:nil];
    NSString *get = [[NSString alloc] initWithData:response encoding:NSUTF8StringEncoding];
    self.statusBar.title = get;
    
}

- (void) awakeFromNib {
    self.statusBar = [[NSStatusBar systemStatusBar] statusItemWithLength:NSVariableStatusItemLength];

    NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:@"http://stardock.cs.virginia.edu/miller/queue_count.php"]];
    NSData *response = [NSURLConnection sendSynchronousRequest:request returningResponse:nil error:nil];
    NSString *get = [[NSString alloc] initWithData:response encoding:NSUTF8StringEncoding];
    self.statusBar.title = get;
    
    [NSTimer scheduledTimerWithTimeInterval:15.0
                                     target:self
                                   selector:@selector(getCount)
                                   userInfo:nil
                                    repeats:YES];
    
    //self.statusBar.title = get;

    // you can also set an image
    //self.statusBar.image =
    
    self.statusBar.menu = self.menu_thingy;
    self.statusBar.highlightMode = YES;
}

@end

//
//  AppDelegate.h
//  OfficeHours
//
//  Created by Dan Miller on 4/2/13.
//  Copyright (c) 2013 Dan Miller. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>

@property (assign) IBOutlet NSWindow *window;

@property (weak) IBOutlet NSMenu *menu_thingy;

@property (strong, nonatomic) NSStatusItem *statusBar;
@end

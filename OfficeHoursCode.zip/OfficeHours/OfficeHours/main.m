//
//  main.m
//  OfficeHours
//
//  Created by Dan Miller on 4/2/13.
//  Copyright (c) 2013 Dan Miller. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc, (const char **)argv);
}

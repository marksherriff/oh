﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OfficeHours
{
    public class SysTrayApp : Form
    {
        [STAThread]
        public static void Main()
        {
            Application.Run(new SysTrayApp());
        }

        private NotifyIcon trayIcon;
        private ContextMenu trayMenu;
        private Timer timer;

        private int currentTotal;

        public void GetTotal(object sender, EventArgs e)
        {
            WebRequest request = WebRequest.Create("http://stardock.cs.virginia.edu/miller/queue_count.php");
            WebResponse response = request.GetResponse();
            Stream data = response.GetResponseStream();
            string html = String.Empty;
            using (StreamReader sr = new StreamReader(data))
            {
                html = sr.ReadToEnd();
            }

            int newTotal = Convert.ToInt32(html);
            if (currentTotal == 0 && newTotal != 0)
            {
                trayIcon.BalloonTipIcon = ToolTipIcon.Info;
                trayIcon.BalloonTipTitle = "Queue Notification";
                trayIcon.BalloonTipText = "Someone is in the queue now!";
                trayIcon.ShowBalloonTip(30000);
            }

            currentTotal = newTotal;
            trayIcon.Text = currentTotal.ToString();
        }

        public SysTrayApp()
        {
            WebRequest request = WebRequest.Create("http://stardock.cs.virginia.edu/miller/queue_count.php");
            WebResponse response = request.GetResponse();
            Stream data = response.GetResponseStream();
            string html = String.Empty;
            using (StreamReader sr = new StreamReader(data))
            {
                html = sr.ReadToEnd();
            }

            currentTotal = Convert.ToInt32(html);

            timer = new Timer();
            timer.Tick += new EventHandler(GetTotal);
            timer.Interval = 15000;
            timer.Start();

            trayMenu = new ContextMenu();
            trayMenu.MenuItems.Add("Exit", OnExit);

            trayIcon = new NotifyIcon();
            trayIcon.Text = currentTotal.ToString();
            trayIcon.Icon = new Icon(SystemIcons.Application, 40, 40);

            trayIcon.ContextMenu = trayMenu;
            trayIcon.Visible = true;
        }

        protected override void OnLoad(EventArgs e)
        {
            Visible = false;
            ShowInTaskbar = false;

            base.OnLoad(e);
        }

        private void OnExit(object sender, EventArgs e)
        {
            Application.Exit();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                trayIcon.Dispose();
            }

            base.Dispose(disposing);
        }
    }
}
